package com.example.tugas2;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class activity_main3 extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);
    }
    public void button5(View view) {
        Intent intent = new Intent(activity_main3.this, MainActivity.class);
        startActivity(intent);
    }
    public void button6(View view) {
        Intent intent = new Intent(activity_main3.this, activity_main2.class);
        startActivity(intent);
    }
}
